#ifndef RECTOWERSOFHANOI_H
#define RECTOWERSOFHANOI_H

#include "AbstractTowersOfHanoi.h"

class RecTowersOfHanoi: public AbstractTowersOfHanoi
{
public:
    void solve(int numDisks)
    {
        solution.clear();
        solve(numDisks,1,3,2);
    }

    void solve(int numDisks,int from,int to,int inter)
    {
        if (numDisks>0)
        {
            solve(numDisks-1,from,inter,to);
            solution.push_back(Move(from,to));
            solve(numDisks-1,inter,to,from);
        }
    }

};

#endif // RECTOWERSOFHANOI_H
