#include <iostream>
#include <string>
#include <fstream>
using namespace std;
#include "RecTowersOfHanoi.h"
#include "NonRecTowersOfHanoi.h"




int main(int argc, char *argv[])
{
    NonRecTowersOfHanoi solver;
    int problemSize = 20;
    stringstream temp;

    temp << "toh-" << problemSize << ".txt";

    ofstream out(temp.str().c_str());

    solver.solve(problemSize);
    solver.exportSolution(out);
    return 0;
}

