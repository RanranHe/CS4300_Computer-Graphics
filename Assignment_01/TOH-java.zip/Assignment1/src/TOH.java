import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import cs4300.assignment1.RecTowersOfHanoi;

/**
 * A main class to test towers of hanoi
 */
public class TOH {
  public static void main(String []args) {
    cs4300.assignment1.TowersOfHanoi solver;

    solver = new cs4300.assignment1.NonRecTowersOfHanoi();
    int problemSize = 20;
    String filename = "toh-"+problemSize+".txt";
    solver.solve(problemSize);
    OutputStream out = null;
    try {
      out = new FileOutputStream(filename);
    } catch (FileNotFoundException e) {
      System.out.println("Could not write to file "+filename);
    }
    solver.export(out);
    try {
      out.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
