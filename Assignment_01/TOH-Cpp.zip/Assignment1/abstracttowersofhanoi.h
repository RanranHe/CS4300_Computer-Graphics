#ifndef ABSTRACTTOWERSOFHANOI_H
#define ABSTRACTTOWERSOFHANOI_H

#include "TowersOfHanoi.h"
#include "Move.h"
#include <list>
using namespace std;

class AbstractTowersOfHanoi: public TowersOfHanoi
{
public:
    AbstractTowersOfHanoi()
    {}

    void exportSolution(ostream& out)
    {
        out << solution.size() << endl;

        for (list<Move>::iterator it=solution.begin();it!=solution.end();it++)
        {
          out << it->getFrom() << " " << it->getTo() << endl;
        }
        out.flush();
      }
protected:
    list<Move> solution;
};

#endif // ABSTRACTTOWERSOFHANOI_H
