#ifndef MOVE_H
#define MOVE_H

class Move
{
public:
    Move(int f,int t)
    {
        this->from = f;
        this->to = t;
    }

    int getFrom() const
    {
        return from;
    }

    int getTo() const
    {
        return to;
    }

private:
    int from;
    int to;
};

#endif // MOVE_H
