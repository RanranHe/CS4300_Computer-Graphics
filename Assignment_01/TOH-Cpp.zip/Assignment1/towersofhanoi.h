#ifndef TOWERSOFHANOI_H
#define TOWERSOFHANOI_H
#include <ostream>
using namespace std;

class TowersOfHanoi
{
public:
    virtual void solve(int numDisks)=0;
    virtual void exportSolution(ostream& o)=0;

};

#endif // TOWERSOFHANOI_H
