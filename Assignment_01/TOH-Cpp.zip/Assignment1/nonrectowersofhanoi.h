#ifndef NONRECTOWERSOFHANOI_H
#define NONRECTOWERSOFHANOI_H

#include <stack>
#include <sstream>
using namespace std;
#include "AbstractTowersOfHanoi.h"

class NonRecTowersOfHanoi: public AbstractTowersOfHanoi
{
public:
    void solve(int numDisks)
    {
        stack<string> moveStack;
        stringstream temp;
        int disks,from,to,inter;
        char command;

        solution.clear();

        temp << "p " << numDisks << " 1 3 2";

        moveStack.push(temp.str());
        while (!moveStack.empty())
        {
            string curr = moveStack.top();
            moveStack.pop();

            if (curr[0] == 'p')
            {
                temp.str("");
                temp.clear();
                temp << curr;
                temp >> command >> disks >> from >> to >> inter;

                if (disks>0)
                {
                    temp.str("");
                    temp.clear();
                    temp << "p " << disks-1 << " " << inter << " " << to << " " << from;
                    moveStack.push(temp.str());

                    temp.str("");
                    temp.clear();
                    temp << "c " << from << " " << to;
                    moveStack.push(temp.str());

                    temp.str("");
                    temp.clear();
                    temp << "p " << disks-1 << " " << from << " " << inter << " " << to;
                    moveStack.push(temp.str());

                }
            }
            else if (curr[0] == 'c')
            {
                temp.str("");
                temp.clear();
                temp << curr;
                temp >> command >> from >> to;
                solution.push_back(Move(from,to));

            }
        }
    }


};

#endif // NONRECTOWERSOFHANOI_H
